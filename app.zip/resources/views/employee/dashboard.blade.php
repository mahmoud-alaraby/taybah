<!-- resources/views/employee/dashboard.blade.php -->
@extends('employee.layouts.app')

@section('title', 'الرئيسية')
@section('page-title', 'لوحة التحكم')
@section('page-subtitle', 'مرحباً ' . auth("employee")->user()->name . '، إليك نظرة عامة على النظام')

@section('content')
<div class="space-y-6">
    <!-- Welcome Card -->
    <div class="bg-white overflow-hidden shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <div class="h-16 w-16 bg-red-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mr-5">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                        مرحباً بك {{ auth('employee')->user()->name }}
                    </h3>
                    <p class="mt-1 text-sm text-gray-500">
                        {{ auth('employee')->user()->position }} - {{ auth('employee')->user()->department_name }}
                    </p>
                    <p class="mt-1 text-sm text-gray-500">
                        رقم الموظف: {{ auth('employee')->user()->employee_id }}
                    </p>
                </div>
            </div>
        </div>
    </div>

  <!-- Employee Info Stats -  -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
    <!-- Roles Count -->
    <div class="bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-xl p-5 text-white shadow-lg">
        <div class="flex items-center">
            <div class="flex-shrink-0">
                <div class="h-8 w-8 bg-indigo-700 rounded-md flex items-center justify-center">
                    <i class="fas fa-user-tag text-white text-sm"></i>
                </div>
            </div>
            <div class="mr-5 w-0 flex-1">
                <dl>
                    <dt class="text-sm opacity-90 truncate">
                        الأدوار المعينة
                    </dt>
                    <dd class="text-2xl font-bold">
                        {{ auth('employee')->user()->roles->count() }}
                    </dd>
                </dl>
            </div>
        </div>
    </div>

    <!-- Permissions Count -->
    <div class="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-xl p-5 text-white shadow-lg">
        <div class="flex items-center">
            <div class="flex-shrink-0">
                <div class="h-8 w-8 bg-emerald-700 rounded-md flex items-center justify-center">
                    <i class="fas fa-key text-white text-sm"></i>
                </div>
            </div>
            <div class="mr-5 w-0 flex-1">
                <dl>
                    <dt class="text-sm opacity-90 truncate">
                        الصلاحيات المتاحة
                    </dt>
                    <dd class="text-2xl font-bold">
                        {{ $permissions->count() }}
                    </dd>
                </dl>
            </div>
        </div>
    </div>

    <!-- Last Login -->
    <div class="bg-gradient-to-r from-pink-500 to-pink-600 rounded-xl p-5 text-white shadow-lg">
        <div class="flex items-center">
            <div class="flex-shrink-0">
                <div class="h-8 w-8 bg-pink-700 rounded-md flex items-center justify-center">
                    <i class="fas fa-clock text-white text-sm"></i>
                </div>
            </div>
            <div class="mr-5 w-0 flex-1">
                <dl>
                    <dt class="text-sm opacity-90 truncate">
                        آخر دخول
                    </dt>
                    <dd class="text-2xl font-bold">
                        الآن
                    </dd>
                </dl>
            </div>
        </div>
    </div>
</div>


@php
    // تأكد أن $permissions هي Collection ثم خذ فقط الصلاحيات الفريدة حسب 'name'
    $uniquePermissions = collect($permissions)->unique('name')->values();
    
    // أيقونات كل سيستم
    $icons = [
        'receipts_payments' => 'fa-money-bill-wave',
        'customer_movement' => 'fa-users',
        'potential_customers' => 'fa-user-plus',
        'stopwatch_system' => 'fa-stopwatch',
        'general_operations' => 'fa-cogs',
        'photography_booking' => 'fa-camera',
        'designers_account' => 'fa-palette',
        'customer_response' => 'fa-comments',
        'task_list' => 'fa-tasks',
        'renewal_dates' => 'fa-calendar-alt',
        'photography_costs' => 'fa-dollar-sign',
        'customer_communication' => 'fa-phone',
        'design_follow_up' => 'fa-pencil-ruler',
        'montage_follow_up' => 'fa-video',
    ];

    // ألوان التدرجات للبوردر والأيقونة
    $cardGradients = [
        ['#ec4899', '#ef4444'], // وردي -> أحمر
        ['#3b82f6', '#6366f1'], // أزرق -> بنفسجي
        ['#22c55e', '#14b8a6'], // أخضر -> فيروزي
        ['#f59e42', '#fbbf24'], // برتقالي -> أصفر
        ['#a21caf', '#f472b6'], // بنفسجي غامق -> وردي فاتح
        ['#0ea5e9', '#06b6d4'], // أزرق فاتح -> أزرق سماوي
        ['#7c3aed', '#c026d3'], // بنفسجي -> أرجواني
        ['#b91c1c', '#f87171'], // أحمر غامق -> وردي فاتح
        ['#64748b', '#334155'], // رمادي -> رمادي غامق
    ];
@endphp

<div class="bg-white shadow rounded-lg">
    <div class="px-4 py-5 sm:p-6">
        <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">الأنظمة المتاحة لك</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            @forelse($uniquePermissions as $index => $permission)
                @php
                    $icon = $icons[$permission->name] ?? 'fa-cog';

                    // احصل على التدرج حسب رقم الكارد
                    $gradient = $cardGradients[$index % count($cardGradients)];
                    $borderGradient = "linear-gradient(90deg, {$gradient[0]}, {$gradient[1]})";
                    $iconGradient = "background: linear-gradient(90deg, {$gradient[0]}, {$gradient[1]}); -webkit-background-clip: text; -webkit-text-fill-color: transparent;";
                @endphp

                <div class="relative block bg-white shadow-md rounded-lg p-5 transition-transform hover:scale-105"
                     style="border-top: 5px solid transparent; border-image: {{ $borderGradient }} 1;">
                    <div class="text-center">
                        <i class="fas {{ $icon }} text-3xl mb-2"
                           style="{{ $iconGradient }}"></i>
                        <span class="block text-sm font-medium text-gray-900">{{ $permission->display_name }}</span>
                        <span class="block text-xs text-gray-500 mt-1">{{ $permission->description }}</span>
                    </div>
                </div>
            @empty
                <div class="col-span-full text-center py-12">
                    <i class="fas fa-exclamation-triangle text-6xl text-gray-400 mb-4"></i>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">لا توجد صلاحيات</h3>
                    <p class="text-sm text-gray-500">لم يتم تعيين أي صلاحيات لحسابك حتى الآن</p>
                </div>
            @endforelse
        </div>
    </div>
</div>



  <!-- Current Roles -->
<div class="bg-white shadow-md rounded-xl overflow-hidden">
    <div class="px-6 py-6">
        <h3 class="text-xl font-semibold text-gray-900 mb-5 flex items-center">
            <i class="fas fa-user-shield ml-2 text-gradient"></i>
            الأدوار المعينة لك
        </h3>
        <div class="space-y-4">
            @forelse(auth('employee')->user()->roles as $role)
                <div class="flex items-center justify-between p-5 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg hover:shadow-lg transition">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="h-10 w-10 rounded-md flex items-center justify-center bg-gradient-to-tr from-red-500 to-red-500 shadow-md">
                                <i class="fas fa-user-tag text-white text-sm"></i>
                            </div>
                        </div>
                        <div class="mr-4">
                            <p class="text-base font-medium text-gray-900">{{ $role->name }}</p>
                            <p class="text-sm text-gray-500">{{ $role->description }}</p>
                        </div>
                    </div>
                    <div class="flex items-center text-sm text-gray-600">
                        <i class="fas fa-key ml-1 bg-gradient-to-tr from-red-400 to-red-500 bg-clip-text text-transparent"></i>
                        {{ $role->permissions->count() }} صلاحيات
                    </div>
                </div>
            @empty
                <div class="text-center py-10">
                    <i class="fas fa-user-times text-5xl bg-gradient-to-tr from-gray-400 to-gray-600 bg-clip-text text-transparent mb-4"></i>
                    <p class="text-base text-gray-500">لم يتم تعيين أي أدوار لحسابك</p>
                </div>
            @endforelse
        </div>
    </div>
</div>



</div>


@endsection